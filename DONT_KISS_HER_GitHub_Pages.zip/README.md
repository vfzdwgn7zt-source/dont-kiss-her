# DON'T KISS HER

iPhone Safari 向けホラー脱出・シナリオ選択ゲームの開発版です。

## GitHub Pages で公開する手順

1. GitHub で新しい Public Repository を作成
2. このZIPの中身（index.html / .nojekyll）をリポジトリ直下へアップロード
3. Repository の Settings → Pages
4. Build and deployment:
   - Source: Deploy from a branch
   - Branch: main
   - Folder: / (root)
5. Save
6. 数分後に表示される GitHub Pages URL を iPhone Safari で開く

## セーブ
ゲームのセーブデータは Safari の localStorage に保存されます。
同じ GitHub Pages URL で遊ぶ限り、セーブデータ・ENDING ARCHIVE・GAME OVER COLLECTIONが保持されます。

## ファイル
- index.html : ゲーム本体
- .nojekyll : GitHub Pages 用
